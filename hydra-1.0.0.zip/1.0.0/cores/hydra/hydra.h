/*
 * Copyright (c) 2021, TC LIFTING EQUIPMENT CO., LTD
 * All rights reserved.
 */


#ifndef __HYDRA50__H
#define __HYDRA50__H
#include "Arduino.h"

void hydraInitDefault();

